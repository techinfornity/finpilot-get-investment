const { getAssetDetails, getInvestmentSummaryHistory } = require('./aws/dynamodb/InvestmentRepository');

exports.handler = async (event) => {
    try {
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const assetType = body && body.assetType ? body.assetType.toUpperCase() : 'CASH';
        const userId = body && body.username ? body.username : undefined;
        const result = await getAssetDetails(assetType, userId);
        let response = { assetType, details: result };
        if (assetType === 'CASH') {
            const investmentSummaryHistory = await getInvestmentSummaryHistory(userId);
            response.investmentSummaryHistory = investmentSummaryHistory;
        }
        return {
            statusCode: 200,
            body: JSON.stringify(response)
        };
    } catch (error) {
        console.log(error);
        throw new Error("internal server error");
    }
}